<?php


header("Location: http://www.cinnamongourmet.com/");
die();

?>