 <?php if($count = Auth::user()->unreadNotifications->count()): ?> 
    <span class='badge white'>
        <span class='text-dark '><?php echo e($count); ?>

        </span>
    </span>

   
    <audio autoplay src="<?php echo e(URL::asset("/storage/song.mp3")); ?>" >
        <p>If you are reading this, it is because your browser does not support the audio element.</p>
        </audio> 

<?php endif; ?> <?php /**PATH D:\AppServ\www\posshop\resources\views/notifications/unread.blade.php ENDPATH**/ ?>