


<?php $__env->startSection('tittle', 'Productos'); ?>

<?php $__env->startSection('content'); ?>
<br>
<br>
<div class="container">
          


        <div class="products ">
            <div class="text-center"><h4><strong> <?php echo e($favorito->descripcion); ?> </strong></h4></div>
            <br>    
            <div class="container ">
                <div class="row ">
                
                
                    <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col pb-5">
    

    
                            <a href="<?php echo e(route('articulos.show',  $articulo->id)); ?>" class="list-group-item-action">
                                <div class="card  "  style="width: 19rem;">
                                    <div class="card-header ">
                                        
                                            <div class="column p-1">
                                                
                                                    <img src="<?php echo e(URL::asset("/storage/img/articulos/$articulo->imagen")); ?>"
                                                    class="card-img-top mx-auto" style="height: 250px; width: 250px;display: block;"
                                                    alt="<?php echo e($articulo->imagen); ?>">
        
                        
                                                
                                            </div>
                                    </div>
                                    <div class="card-body p-0" style="height: 6rem;">
                                            <div  class="capitalize text-center">
                                                <h5 class="capitalize">
                                                    <?php echo e($articulo->descripcion); ?>

                                                </h5>
                                                <strong>
                                                    <span class="text-center ">
                                                        $ <?php echo e(number_format($articulo->precio, 0)); ?>

                                                    </span>
                                                </strong>
                                            </div>
                                        
                                    </div>
                                </div>
                                </a>
    
    
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
    
                </div>
            </div>
            
                <div class=" text-center mt-5" >
                  
                        
                    <a class="btn btn-outline-primary  mt-2   white-text capitalize  "  style="width: 16rem;"  title="Categorias" href="<?php echo e(route('categorias.index')); ?>">
                        <h5><i class="fas fa-arrow-left"></i> Categorias </h5>
                    </a>
               

                </div>

                <div >
                    <?php if( $articulosCount>0): ?>


                        <div class="form-group text-center p-0">
                            <br>
                            <a class="btn btn-secondary w-50 white-dark"  class="tooltip-test" title="Pedido" href="<?php echo e(url('/carrito')); ?>">
                                <h5><i class="fas fa-shopping-cart "></i> <span class="capitalize"> Ver Carrito</span></h5>
                            </a>
                        </div>

                    
                    <?php endif; ?>
                </div>




        </div>




</div>


<br>
<br>










<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppServ\www\posshop\resources\views/categorias/show.blade.php ENDPATH**/ ?>