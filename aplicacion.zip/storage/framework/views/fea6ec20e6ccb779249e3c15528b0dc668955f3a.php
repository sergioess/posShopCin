

<?php if( $articulosCount=0): ?>
    return redirect('categorias.index');
<?php else: ?>

    





    <?php $__env->startSection('content'); ?>

        <?php if($StatusPasarela=="APPROVED"): ?>
             <?php echo e($StatusPasarela); ?>  

            <script type="text/javascript">

            

                window.onload=function(){
                    var auto = setTimeout(function(){ autoRefresh(); }, 100);
            
                    function submitform(){
                      
                      document.forms["theForm"].submit();
                    }
            
                    function autoRefresh(){
                       clearTimeout(auto);
                       auto = setTimeout(function(){ submitform(); autoRefresh(); }, 1000);
                    }
                }             

            </script>

        <?php endif; ?>

        <div class="container ">
            <br>
            <br>

            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card p-0">
                        <div class="card-header text-center"><h2>Tu Pedido para <?php echo e($shopping_cart->tipo); ?></h2>
        
                        
                        </div>
                        <div class="card-body p-2">
                            <div class="table-responsive mb-0 mt-0">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <td>Cant</td>
                                            <td>Artículo</td>
                                            <td>Precio</td>
                                            <td></td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                         
                                        <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                                            <tr >
                                                <td class="p-0"> 

                                                    <form method="POST" id="<?php echo e($articulo->innshop_id); ?>"  action="<?php echo e(route('in_shopping_carts.update', $articulo->innshop_id)); ?>">
                                                        <?php echo method_field('PUT'); ?>

    
                                                        <?php echo csrf_field(); ?> 
                                                        <div class="form-group align-middle ">
                                                            
                                                            <select class=' form-control-sm modifcant align-middle' value="<?php echo e($articulo->cantidad); ?>" name="cantidad" id="exampleFormControlSelect1" data-artidcan="<?php echo e($articulo->innshop_id); ?>">
                                                                <?php for($i = 1; $i < 11; $i++): ?>
                                                                    <?php if($i == $articulo->cantidad): ?>
                                                                        <option value="<?php echo e($i); ?>" selected><?php echo e($i); ?></option>
                                                                    
                                                                    <?php else: ?>
                                                                    
                                                                        <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                                                    <?php endif; ?>
                                                                    
                                                                <?php endfor; ?>

 
                                                            </select>
                                                        
                                                        </div>
                                                    </form>	
                                                </td>
                                                <td class="p-1"> <?php echo e($articulo->descripcion); ?> </td>
                                                <td class="p-1" style="text-align:right"> $ <?php echo e(number_format($articulo->precio * $articulo->cantidad, 0)); ?> </td>
                                                <td  class="p-1" style="text-align:right">


                                                    <a class=" "  class="tooltip-test" title="Eliminar del Pedido" href="<?php echo e(route('in_shopping_carts.delete', $articulo->cod)); ?>">
                                                        <h5><i class="fas fa-trash-alt" style="color:orange;margin-right: 0px;"></i></h5>
                                                    </a>
                                                </td>
                                            </tr>
                                    
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" >

                                            
                                            <?php echo app('arrilot.widget')->run('muestramodificador', ['articulo_id' => $articulo->artid  , 'shopping_cart' => $shopping_cart->id ]); ?> 

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr >

                                            <td colspan="4">
                                                <div class="row  p-0">
                                                    <div class="col float-left" style=" height: auto;">
                                                        
                                                        <h3 class="text-center">Total</h3>
                                                    </div>
                                                    <div  class="col float-right">
                                                        <h4 class="text-right" style="margin-right: 5px;">$ <?php echo e(number_format($total, 0)); ?></h4>
                                                    </div>

                                                </div>
                                            </td>

                                        </tr> 
                                        
                                    </tbody> 
                                </table>
                            </div>
                        </div>
                        
                        
                        <div class="mb-0 p-3 mt-0">
                             
                            <h5 class="text-center border rounded-lg " style="background-color:<?php echo e($empresa->navvar); ?>;">
                                <div class="p-2" style="color:<?php echo e($empresa->colletraenca); ?>;">
                                    Sugerencias para ti
                                </div>
 
                            </h5>
                            
                        </div>
                        <br>
                        <?php $__currentLoopData = $articulosAdicionaes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articuloAdicional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <form  action="<?php echo e(url('/in_shopping_carts')); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" value="<?php echo e($articuloAdicional->id); ?>" id="id" name="articulo_id">

                                <input type="hidden" value="1" id="quantity" name="quantity">
                                <input type="hidden" value="1" id="quantity" name="cantidad">
                                <input type="hidden" value="<?php echo e($articuloAdicional->precio); ?>" id="price" name="price">
                                <input type="hidden" value="1" id="quantity" name="shopp">

                                <div class="container-fluid p-0" style="margin-left: 15px;">
                                
                                    <div class="row container-fluid p-0">
                                        <div class="col float-left" style=" height: auto;">
                                            
                                            <img src="<?php echo e(URL::asset("/storage/img/articulos/$articuloAdicional->imagen")); ?>"
                                            class="card-img-top mx-auto" style="height: 67px; width: 100px;display: block;"
                                            alt="<?php echo e($articuloAdicional->imagen); ?>">

                                            
                                        </div>
                                        <div  class="col-7 float-right">
                                            <h6>
                                                <?php echo e(ucfirst($articuloAdicional->descripcion)); ?>

                                            </h6>
                                            <p>$ <?php echo e(number_format($articuloAdicional->precio, 0)); ?></p>
                                        </div>
                                        <div class="col float-right p-2 text-center" >
                                            
                                            <button class="btn btn-link btn-sm p-0"  class="tooltip-test" title="Agregar al Carrito" style="color:orange;margin-right: 0px;">
                                                <h5><i class="fas fa-cart-plus " style="color:orange;margin-right: 0px;"></i> </h5>
                                            </button>
                                        </div>
                                    </div>
            
                                </div>
                            </form>
                            <hr class="p-0">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <br>


                        <div class="container">
                            <div class="row justify-content-center">
                                
                                    <div class="col-xs col-sm-10 col-md-8 ">

                                            <a class="btn btn-primary btn-block p-2 text-capitalize "  href="<?php echo e(url('inicia')); ?>">
                                                <h5> Continuar <i class="fas fa-hand-point-right"></i></h5>
                                            </a>
                                        
                                            <br>
                                    </div>
                                
                            </div>
                        </div>

                        


                        <div class="container">
                            
                            <div class="row align-items-center justify-content-center mb-2">
                                
                                <div class="col col-sm-10 col-md-8 ">
                                    <a class="btn btn-outline-primary  btn-block  white-text capitalize"  class="tooltip-test" title="Categorias" href="<?php echo e(route('categorias.index')); ?>">
                                        <h5><i class="fas fa-arrow-left"></i> Categorias</h5>
                                    </a>
                                </div>
                            
                            </div>                                

                        </div>
                    </div>
                </div>
            </div>  

            


        </div>
        <br>
        <br>




        

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
    
    <script type="text/javascript">

        $.ajaxSetup({
            headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
          });

          
        $(".modifchecker").on("change", function() {
            
            var shopId = $(this).attr("data-shopid"); // gets task ID of clicked checkbox
            var artId = $(this).attr("data-artid"); // gets task ID of clicked checkbox
            var modId = $(this).attr("data-modid");
 
            var ides = '#'+modId;
            //alert(ides);

            $(ides).submit();
        });

        $(".modifcant").on("change", function() {
            

            var modId = $(this).attr("data-artidcan");
 
            var ides = '#'+modId;
            //alert(ides);

            $(ides).submit();
        });

        

    </script>


    <?php $__env->stopSection(); ?>

<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppServ\www\posshop\resources\views/shoppingcarts/index.blade.php ENDPATH**/ ?>