
    

    <?php $__env->startSection('content'); ?>

        <div class="container ">
<br>
<br>


              
            
                <div class="row justify-content-center">
                    <div class="col-md-12">
                        <?php if($vista == '1'): ?>
                            <header class="p-1 text-center blue-grey white-text">

                                <?php if($shopping_cart->tipo <> "Reserva"): ?>
                                    <h1>Pedidos Nuevos</h1>
                                <?php else: ?>
                                    <h1>Reserva Nueva</h1>
                                <?php endif; ?>
                        
                            </header>
                            <div class="card">
                            
                                    <div class="card-header text-center">
                                            
                                        <?php if($shopping_cart->tipo <> "Reserva"): ?>

                                            <?php if($shopping_cart->tipo == "Mesa"): ?>

                                                <h2>Tu Pedido para <?php echo e($shopping_cart->tipo); ?>  <?php echo e($order->mesa); ?></h2>
                                            <?php else: ?>
                                                <h2>Tu Pedido para <?php echo e($shopping_cart->tipo); ?></h2>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <h2>Datos de la Reserva</h2>
                                        <?php endif; ?>
                                    </div>
                                
                                    <div class="card-body ">

                                        
                                        <table style="text-transform: none;" class="table table-condensed">
                                            <tbody>
                                                <tr>
                                                    <th><strong>Pedido ID:</strong></th>
                                                    <td><?php echo e($shopping_cart->customid); ?></td>
                                                </tr>                                    
                                                <tr>
                                                    <th><strong>Nombre:</strong></th>
                                                    <td><?php echo e($order->nombre_recibe); ?></td>
                                                </tr>


                                                <?php if($shopping_cart->tipo <> "Reserva"): ?>

                                                    <?php if($shopping_cart->tipo == "Domicilio"): ?>
                                                        <tr>
                                                            <th><strong>Teléfono:</strong></th>
                                                            <td><?php echo e($order->email); ?></td>
                                                        </tr>                                                    
                                                        <tr>
                                                            <th><strong>Teléfono:</strong></th>
                                                            <td><?php echo e($order->telefono); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th><strong>Dirección:</strong></th>
                                                            <td><?php echo e($order->direccion); ?></td>
                                                        </tr>                                                    
                                                        <tr>
                                                            <th><strong>Barrio</strong></th>
                                                            <td><?php echo e($order->barrio); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th><strong>Ciudad</strong></th>
                                                            <td><?php echo e($order->ciudad.' - '.$order->departamento.' - '.$order->pais); ?></td>
                                                        </tr>
            
                                                    <?php endif; ?>                                                
                                                    <tr>
                                                        <th><strong>Observaciones</strong></th>
                                                        <td><?php echo e($order->line1); ?></td>
                                                    </tr> 
                                                    
                                                    <?php if($shopping_cart->tipo == "Mesa"): ?>
                                                        <?php if($empresa->preguntavajilla == 1): ?>
                                                            <tr>
                                                                <th><strong>Servicio con:</strong></th>
                                                                <?php if($order->respuestavajilla == '1'): ?>
                                                                    <td>Desechable</td>
                                                                <?php else: ?>
                                                                    <td>Vajilla</td>
                                                                <?php endif; ?>
                                                            </tr> 
                                                        <?php endif; ?>                                                            
                                                    <?php endif; ?>

                                                    <?php if($shopping_cart->enviado == 1): ?>
                                                        <tr>
                                                            <th><strong>Forma de Pago</strong></th>

                                                            <td>Efectivo</td>

                                                        </tr>      
                                                    <?php else: ?>
                                                    <tr>
                                                        <th><strong>Forma de Pago</strong></th>
                                                        
                                                        <td>Credibanco - <?php echo e($pagos->paymentState); ?> - <?php echo e($pagos->approvalCode); ?> - <?php echo e(number_format($pagos->depositedAmount, 0)); ?></td>

                                                    </tr>                                                                                                    
                                                    <?php endif; ?>

                                                <?php else: ?>
                                                    <tr>
                                                        <th><strong>Teléfono:</strong></th>
                                                        <td><?php echo e($comprador->telefono); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th><strong>Dirección:</strong></th>
                                                        <td><?php echo e($comprador->direccion); ?></td>
                                                    </tr>                                                    
                                                    <tr>
                                                        <th><strong>Barrio</strong></th>
                                                        <td><?php echo e($comprador->barrio); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th><strong>Ciudad</strong></th>
                                                        <td><?php echo e($comprador->ciudad.' - '.$comprador->departamento.' - '.$comprador->pais); ?></td>
                                                    </tr>
                                                <?php endif; ?>



                                            </tbody>
                                        </table>


                                        <?php if($shopping_cart->tipo <> "Reserva"): ?>
                                            <div class="w-100 h-25"  style="background-color: #252020;" ><hr></div>
                                            <div class="table-responsive">
                                                <table class="table table-hover">
                                                    <thead>
                                                        <tr>
                                                            <td>Cant</td>
                                                            <td>Artículo</td>
                                                            <td style="text-align:right">Precio</td>
                
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    
                                                        <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            
                                                            <tr>
                                                                <td> <span class="fs-sm-2-0"><?php echo e($articulo->cantidad); ?></span>  </td>
                                                                <td> <?php echo e($articulo->descripcion); ?> </td>
                                                                <td style="text-align:right"> $ <?php echo e(number_format($articulo->precio * $articulo->cantidad, 0)); ?> </td>

                                                            </tr>
                                                            
                                                            <?php echo app('arrilot.widget')->run('showmodificadorinvoice', ['articulo_id' => $articulo->codart  , 'shopping_cart' => $shopping_cart->id ]); ?> 

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td colspan="1" > <h4>Total</h4>  </td>
                                                            <td colspan="2" style="text-align:right"> <h4>$ <?php echo e(number_format($total, 0)); ?></h4> </td>
                                        
                                                        </tr> 
                                                        
                                                    </tbody> 
                                                </table>
                                            </div>
                                        <?php else: ?>
                    
                                        
                                        <div class="w-100 "  style="background-color: #252020; height:10px" ><hr></div>
                                        <div class="table-responsive">
                                            <table class="table table-hover">
            
                                                <tbody>
                                                    

                                                        <tr>
                                                            <th>Fecha</th>
                                                            <td><?php echo e($reservas->fecha); ?></td>
                                                        </tr>

                                                        <tr>
                                                            <th>Hora</th>
                                                            <td><?php echo e(substr( $reservas->hora,11,5)); ?> </td>
                                                        </tr>

                                                        <tr>
                                                            <th>Personas</th>
                                                            <td><?php echo e($reservas->comensales); ?> </td>
                                                        </tr>

                                                        <tr>
                                                            <th>Observaciones</th>
                                                            <td><?php echo e($reservas->observacion); ?> </td>
                                                        </tr>                                                        

                                                    
            
                                                    
                                                </tbody> 
                                            </table>
                                        </div>
                    
                                        
                                    
                                        <?php endif; ?>



                                    </div>




                                    <div class="card-footer  text-center" style="background-color: white;">
                                        <div class="form-group text-center">


                                            <?php if($shopping_cart->tipo <> 'Reserva'): ?>
                                                <a class="btn btn-primary white-text"  class="tooltip-test" target="_blank" title="Imprimir" href="<?php echo e(route('notifications.show', $shopping_cart->id)); ?>">
                                                    <h5><i class="fas fa-print"></i> Imprimir Pedido</h5>
                                                </a> 
                                            <?php endif; ?>

    
                                        
                                            
                                            <form class="no-padding" id="logout-formw" method="POST" action="<?php echo e(route('notifications.store')); ?>">
                                                <?php echo csrf_field(); ?>

                                                <input type="hidden" name="notificacion_id" value="<?php echo e($id_notificacion); ?>" >
                                                <input type="hidden"  name="shopping_cart_id" value="<?php echo e($shopping_cart->id); ?>" >
                                                <input type="hidden"  name="shopping_cart_tipo" value="<?php echo e($shopping_cart->tipo); ?>" >
                                                <input type="hidden"  name="sender_id" value="<?php echo e($comprador->id); ?>" >
                                                <input type="hidden"  name="recipient_id" value="<?php echo e($receptor_id); ?>" >
                                                <input type="hidden"  name="empresa_id" value="<?php echo e($shopping_cart->empresa_id); ?>" >
                                                
                                                <a class="btn btn-secondary white-text"  class="tooltip-test"  title="Aceptar Pedido" 
                                                    onclick="document.getElementById('logout-formw').submit();">
                                                    <h5><i class="far fa-check-circle"></i> Confirmar</h5>
                                                </a>
                                                <br>


                                            </form>	 

                                        </div>

                                    </div>

                        <?php else: ?>
                            <div class="card">
                                <div class="card-body ">
                                    <h3>Sin Notificaciones Nuevas</h3>
                                </div>
                            </div>
                        <?php endif; ?>                                    

                    </div>
                </div>  

    
        </div>
        <br>
        <br>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppServ\www\posshop\resources\views/notifications/index.blade.php ENDPATH**/ ?>