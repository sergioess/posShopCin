

<?php $__env->startSection('content'); ?>

<div class="container">
    <br>
    <br>

    <div id="content-wrapper">
   
        <section id="main" itemscope="" itemtype="https://schema.org/Product">
            <meta itemprop="url" content="http://localhost:81/prestashop/es/art/5-19-today-is-a-good-day-framed-poster.html#/19-dimension-40x60cm">

            <div class="row product-container">
            <div class="col-md-6">
                
                <section class="page-content" id="content">
                    


                    
                        <div class="images-container">
        
                            <div class="producto-covertura">
                                <img class="rounded shadow border border-dark"  src="<?php echo e(URL::asset("/storage/img/articulos/$articulo->imagen")); ?>" alt="<?php echo e($articulo->imagen); ?>" 
                                    title="<?php echo e($articulo->imagen); ?>" style="width:100%;" itemprop="image">

                            </div>
                        </div>
                </section>
                
                </div>
                <div class="col-md-6">
                    <p><h3 class="text-center"><?php echo e($articulo->descripcion); ?></h3></p>
                    <hr>
                    <div class="product-prices">
                        <div class="h4 ">
                                <span ><strong >Precio Unidad: </strong >  $ <?php echo e(number_format($articulo->precio, 0)); ?></span>
                        </div>
                        Impuestos incluidos

                    </div>

                    
                    
                        <div id="product-description-short-5" itemprop="description">
                            <p>
                                <span style="font-size:10pt;font-weight:normal;font-style:normal;">
                                    
                                </span>
                            </p>
                        </div>

                        <div >
                
                            <form action="<?php echo e(url('/in_shopping_carts')); ?>" method="POST">
                                
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" value="<?php echo e($articulo->id); ?>" id="id" name="articulo_id">
                                <input type="hidden" value="<?php echo e($articulo->referencia); ?>" id="name" name="name">
                                <input type="hidden" value="<?php echo e($articulo->precio); ?>" id="price" name="price">
                                <input type="hidden" value="<?php echo e($articulo->medida); ?>" id="img" name="img">
                                <input type="hidden" value="<?php echo e($articulo->departamento); ?>" id="slug" name="slug">
                                <input type="hidden" value="1" id="quantity" name="quantity">
                                
                                <input type="hidden" value="0" id="quantity" name="shopp">
                                
                                <section class="product-discounts">
                                </section>

                                <div class="d-inline product-quantity clearfix">
                                    <span class="d-inline"><strong >Cantidad : </strong ></span>

        
                                        
                                            <div class="col-md-auto d-inline">
                                                <select class="form-control-sm "  name="cantidad" id="exampleFormControlSelect1" data-artidcan="<?php echo e($articulo->innshop_id); ?>">
                                                    <?php for($i = 1; $i < 11; $i++): ?>
                                                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                                    <?php endfor; ?>

                                                </select>
                                            </div> 
                                        
                                        <div class="d-inline">


                                            <button class="btn btn-primary white-text capitalize work" class="tooltip-test" title="Agregar al Carrito">
                                                <h5><i class="fas fa-shopping-cart "></i> Agregar al Carrito</h5>
                                            </button>
                                        </div>
                                                                    

                                    <span id="product-availability">
                                    </span>
        

                                    
                                    <p class="product-minimal-quantity">
                                    </p>
                                    



                                </div>
                
                            </form>
                

                        </div>
            
                        <div class="tabs">
                            <ul class="nav nav-tabs" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active border border-danger rounded" data-toggle="tab" href="#description" role="tab" aria-controls="description" aria-selected="true">
                                        <strong>Descripción</strong> 
                                    </a>
                                </li>
                                
                            </ul>

                            <div class="tab-content" id="tab-content">
                            <div class="tab-pane in active" id="description" role="tabpanel">
                            
                                <div class="product-description border border-danger rounded shadow  bg-white">
                                    <p class="mt-2 p-1">
                                        <span  style="font-size:12pt;font-style:normal;">
                                            <?php echo e($articulo->descripcion2); ?>

                                        </span>
                                    </p>
                                </div>
                            
                            </div>

 
                

                        </div>  

                        
                        <div class="form-group text-center">
                            <br>
                            <a class="btn btn-outline-primary  btn-block  white-dark"  class="tooltip-test" title="Pedido" href=<?php echo e(route('categorias.show', $favorito->id)); ?>">
                                <h5><i class="fas fa-arrow-left "></i> <span class="capitalize">  <?php echo e($favorito->descripcion); ?> </span></h5>
                            </a>
                        </div>


                        <div  >
                                        
                                            
                            <a class="btn btn-outline-primary  btn-block  white-text capitalize mt-3"  class="tooltip-test" title="Categorias" href="<?php echo e(route('categorias.index')); ?>">
                                <h5><i class="fas fa-arrow-left"></i> Categorias</h5>
                            </a>
                        

                        </div>
                        
                        <div >
                            <?php if( $articulosCount>0): ?>
        
        
                                <div class="form-group text-center ">
                                    <br>
                                    <a class="btn btn-secondary btn-block  white-dark"  class="tooltip-test" title="Pedido" href="<?php echo e(url('/carrito')); ?>">
                                        <h5><i class="fas fa-shopping-cart "></i> <span class="capitalize"> Ver Carrito</span></h5>
                                    </a>
                                </div>
        
                            
                            <?php endif; ?>
                        </div>


                    </div>
                
                    
                </div>
            </div>
                 
        </section>

    </div>

</div>







<br>
<br>
<br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppServ\www\posshop\resources\views/articulos/show.blade.php ENDPATH**/ ?>