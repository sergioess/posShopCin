
 

<?php $__env->startSection('content'); ?>

	

	<div class="container">
		<h1>Listado de Productos <a href="<?php echo e(route('productos.create')); ?>">
			<button class="btn btn-xs btn-link"  data-toggle="tooltip"  title="Crear Producto"><i class="fas fa-plus-circle  fa-3x  text-dark" aria-hidden="true">
				</i></button></a></h1>


		
		<div class="row">

			<div class="form-group two-fields">
				<div class="input-group">
					<form class="form-inline" method="POST" action="<?php echo e(route('productos.show2')); ?>">
						<?php echo csrf_field(); ?>

						<div class="form-group">
							<label for="estado" class="col-xs-12 control-label"><h3>Filtro Categoria</h3></label>

							<select class="form-control" name="categoria" id="categoria" data-toggle="tooltip"  title="Seleccionar una Categoria">

								<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->descripcion); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>

							<input class="btn btn-success p-2"  type="submit" value= "Filtrar" >
						</div>
					</form>
				</div>

			</div>
		</div>


		<div class="table-responsive">
			<table class="table table-striped">
			
				<thead>
					
					<tr>
						<th>#</th>
						
						<th>Nombre</th>				
						<th>Valor</th>
						<th>Imagen</th>				
						<th>Visible</th>
						<th>Editar</th>			
						<th>Opciones</th>	
						<th>Borrar</th>	
					</tr>
	
	
				</thead>
	
	
				<tbody>
					
					<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td>  <?php echo e($loop->iteration); ?>  </td>
						
	
						<td> <?php echo e($producto->descripcion); ?> </td>
						<td> <?php echo e($producto->precio); ?> </td>
						<td> <img src="<?php echo e(URL::asset("/storage/img/articulos/$producto->imagen")); ?>"
							class="card-img-top mx-auto"
							style="height: 66px; width: 99px;display: block;">  
						</td>
						
						<td>
							<a href="#" class="pto-habilitado" data-type="select" data-pk="<?php echo e($producto->id); ?>" 
								data-url="<?php echo e(url("/prodcat/$producto->id")); ?>" 
								data-title="Visible"
								data-value="<?php echo e($producto->habilitado); ?>"
								data-name="habilitado">
							</a>
						</td>
	
						<td> 
							<a href="<?php echo e(route('productos.edit', $producto->id)); ?>" class="btn btn-link btn-xs" data-toggle="tooltip"  title="Editar Producto">
								<i class="fas fa-edit  fa-1x" ></i>
							</a> 
						</td>
						<td> 
							<a href="<?php echo e(route('modificadores.edit', $producto->id)); ?>" class="btn btn-link btn-xs" data-toggle="tooltip"  title="Opciones del Producto">
								<i class="fas fa-check-double fa-1x" ></i>
							</a> 
						</td>						
						<td> 
							
							<a class="tooltip-test" title="Eliminar Producto" href="<?php echo e(route('productos.delete', $producto->id)); ?>">
								<h5><i class="fas fa-trash-alt fa-1x"></i></h5>
							</a>


							
						</td>
	
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
	
	
			</table>
		</div>
	
	</div>

</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>


	<script type="text/javascript">
		$.fn.editable.defaults.mode = 'inline';
		$.fn.editable.defaults.ajaxOptions = {type: "PUT"};


		$.ajaxSetup({

			headers: {

				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

			}

		});
		$('.pto-habilitado').editable({
			source: [
				{value: '1', text: 'Mostrar'}, 
				{value: '0', text: 'Ocultar'}
			]
		});



	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppServ\www\posshop\resources\views/productos/index.blade.php ENDPATH**/ ?>