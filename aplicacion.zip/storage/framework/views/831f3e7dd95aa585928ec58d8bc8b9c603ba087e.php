<?php if(Auth::user()->claseusr == 0): ?>

    <?php
        header("Location: " . URL::to('/categoriasadmin'), true, 302);
        exit();
    ?>

<?php endif; ?>






<?php $__env->startSection('tittle', 'Productos'); ?>

<?php $__env->startSection('content'); ?>
<br>
<br>
<div class="container">
    


    <div class="products ">

        <div class="row justify-content-center p-2" style="background-color:<?php echo e($empresa->navvar); ?>;">
            <span class="  text-white text-center btn-block p-0"><h4>Selecciona una Categoria</h4></span>
            
        </div>

        <div class="row justify-content-center">

            

            <?php $__currentLoopData = $favoritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-sm-12 p-2 ">


                
                <a href="<?php echo e(route('categorias.show', $favorito->id)); ?>" class="list-group-item-action">
                    <div class="  "  style="">
                        <div class=" ">
                            
                                <div class="column p-1">
                                    
                                        <img src="<?php echo e(URL::asset("/storage/img/categorias/$favorito->imagen")); ?>"
                                        class="card-img-top mx-auto d-block" style="height: 400px; width: 400px;display: block;"
                                        alt="<?php echo e($favorito->imagen); ?>">

            
                                    
                                </div>
                        </div>

                    </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

        </div>
            <div class=" text-center" >
              
                    
                <a class="btn btn-outline-primary    white-text capitalize  "  style="width: 16rem;"  title="Categorias" href="<?php echo e(route('categorias.index')); ?>">
                    <h5><i class="fas fa-arrow-left"></i> Categorias </h5>
                </a>
           

            </div>

            <div >
                <?php if( $articulosCount>0): ?>


                    <div class="form-group text-center p-3">
                        <br>
                        <a class="btn btn-secondary w-50  white-dark"  class="tooltip-test" title="Pedido" href="<?php echo e(url('/carrito')); ?>">
                            <h5><i class="fas fa-shopping-cart "></i> <span class="capitalize"> Ver Carrito</span></h5>
                        </a>
                    </div>

                
                <?php endif; ?>
            </div>




    </div>




</div>
<br>
<br>
<br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppServ\www\posshop\resources\views/categorias/index.blade.php ENDPATH**/ ?>