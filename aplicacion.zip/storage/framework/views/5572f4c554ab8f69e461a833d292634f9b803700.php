


<?php $__env->startSection('content'); ?>

<div class="container">

<br>
<br>

	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card large-padding p-2">
	<h1>Productos</h1>



	
    <?php echo Form::open(['method' => 'POST', 'route' => 'productos.store', 'class' => 'form-horizontal', 'files' => true]); ?>


				<?php echo csrf_field(); ?>


				<p><label for="Categoria">
	                <select class="form-control" name="categoria" id="categoria">

	                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                        <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->descripcion); ?></option>
	                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                </select>
	             </label></p>				

 				<p><label for="nombre">
					Nombre
					<input class="form-control"  type="text" name="nombre" value="<?php echo e(old('nombre')); ?>">
					<?php echo $errors->first('nombre','<span class=error>:message</span>'); ?>

				</label></p>  

				<p><label for="descripcion">
					Descripción
					<input class="form-control"  type="text" name="descripcion" value="<?php echo e(old('descripcion')); ?>">
					<?php echo $errors->first('descripcion','<span class=error>:message</span>'); ?>

				</label></p>  

 				<p><label for="valor">
					Valor
					<input class="form-control"  type="text" name="valor" value="<?php echo e(old('valor')); ?>">
					<?php echo $errors->first('valor','<span class=error>:message</span>'); ?>

				
				</label></p>

				<div class="form-group">
					<p><label for="imagen">
						Imagen
                		<?php echo Form::file('imagen', array('class' => 'form-control')); ?>

                
                		<small class="text-danger"><?php echo e($errors->first('imagen')); ?></small>
					</label></p>
				</div>
				



				<p><label for="Medida">
	                <select class="form-control" name="idmedia" id="idmedia">

	                    <?php $__currentLoopData = $medidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                        <option value="<?php echo e($medida->id); ?>"><?php echo e($medida->nombre); ?></option>
	                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                </select>
	             </label></p>
						
				<input type="hidden" name="minimo" value="0" >	
				

				<button class="btn btn-success " type="submit" ><i class='far fa-check-square fa-1x mr-1' aria-hidden="true"   ></i>Guardar</button>
		<?php echo Form::close(); ?>

	
	</div>
</div>
</div>



</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppServ\www\posshop\resources\views/productos/create.blade.php ENDPATH**/ ?>