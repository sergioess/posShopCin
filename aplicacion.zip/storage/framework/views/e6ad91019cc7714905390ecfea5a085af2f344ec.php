<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" />

        <!-- Fonts -->
        <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

        <!-- Google Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">

        <!-- Bootstrap core CSS -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/css/material-fullpalette.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/css/ripples.min.css" rel="stylesheet">


        


    </head>
    <body onload="window.print()">
        <div id="app" >

            <div class="row">
                <div class="col-5">
            
                    <table  class="table  table-borderless">
                        <tbody>
                            <tr>
                                <?php if($shopping_cart->tipo == "Mesa"): ?>

                                
                                    <th colspan="2"><strong><h2>Tu Pedido para <?php echo e($shopping_cart->tipo); ?>   <?php echo e($order->mesa); ?></h2></strong></th>
                                <?php else: ?>
                                    <th colspan="2"><strong><h2>Tu Pedido para <?php echo e($shopping_cart->tipo); ?></h2></strong></th>
                                <?php endif; ?>

                                
                            </tr>                                    
                            <tr>
                                <th><strong>Pedido ID:</strong></th>
                                <td><?php echo e($shopping_cart->customid); ?></td>
                            </tr>                                    
                            <tr>
                                <th><strong>Nombre:</strong></th>
                                <td><?php echo e($order->nombre_recibe); ?></td>
                            </tr>

                            <?php if($shopping_cart->tipo <> "Mesa"): ?>

                                <tr>
                                    <th><strong>Teléfono:</strong></th>
                                    <td><?php echo e($order->telefono); ?></td>
                                </tr>
                                <tr>
                                    <th><strong>Dirección:</strong></th>
                                    <td><?php echo e($order->direccion); ?></td>
                                </tr>                                                    
                                <tr>
                                    <th><strong>Barrio</strong></th>
                                    <td><?php echo e($order->barrio); ?></td>
                                </tr>
                                <tr>
                                    <th><strong>Ciudad</strong></th>
                                    <td>
                                        <?php echo e($order->ciudad.' - '.$order->departamento.' - '.$order->pais); ?>


                                    </td>
                                </tr>

                            <?php endif; ?>
                        </tbody>
                    </table>
    
            

                    <table class="table  table-borderless">
                        <thead>
                            <tr>
                                <td>Cant</td>
                                <td>Artículo</td>
                                <td style="text-align:right">Precio</td>

                            </tr>
                        </thead>
                        <tbody>
                    
                            <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td> <span class="fs-sm-2-0"><?php echo e($articulo->cantidad); ?></span>  </td>
                                    <td> <?php echo e($articulo->descripcion); ?> </td>
                                    <td style="text-align:right"> $ <?php echo e(number_format($articulo->precio * $articulo->cantidad, 0)); ?> </td>

                                </tr>
                                
                                <?php echo app('arrilot.widget')->run('showmodificadorinvoice', ['articulo_id' => $articulo->codart  , 'shopping_cart' => $shopping_cart->id ]); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="1" > <h4>Total</h4>  </td>
                                <td colspan="2" style="text-align:right"> <h4>$ <?php echo e(number_format($total, 0)); ?></h4> </td>
            
                            </tr> 
                            <tr>

                                <th colspan="3">Observaciones</th>
                            </tr>                       
                            <tr>

                                <td colspan="3"><?php echo e($order->line1); ?></td>
                            </tr>                      
                                
                            <?php if($shopping_cart->tipo == "Mesa"): ?>
                                <?php if($empresa->preguntavajilla == 1): ?>
                                    <tr>
                                        <th><strong>Servicio con:</strong></th>
                                        <?php if($order->respuestavajilla == '1'): ?>
                                            <td>Desechable</td>
                                        <?php else: ?>
                                            <td>Vajilla</td>
                                        <?php endif; ?>
                                    </tr> 
                                    
                                <?php endif; ?>                                      
                            <?php endif; ?>

                        </tbody> 
                    </table>
        
                </div>
            </div>

        </div>
    <br>
    <br>


</body>
</html>
  
<?php /**PATH D:\AppServ\www\posshop\resources\views/invoice.blade.php ENDPATH**/ ?>