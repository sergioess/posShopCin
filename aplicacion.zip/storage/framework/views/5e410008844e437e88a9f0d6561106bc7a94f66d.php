
<?php /**PATH D:\AppServ\www\posshop\resources\views/components/efectivo-collapse.blade.php ENDPATH**/ ?>