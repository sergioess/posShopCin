<?php $__env->startSection('content'); ?>
<br>
<br>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(Cookie::get('namecompany')); ?>


                    <div class="row">
                        <div class="table-responsive">
                            <table class="table ">
                                <tbody>
                                    <tr style="background-color:#FEF7F1">
                                        <td>
                                            <div class="text-center">

                                                
                                                <img src="<?php echo e(URL::asset("/img/logo.png")); ?>" class="img-fluid" alt="">
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>

                    <hr>
                </div>
                
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php else: ?>
                    <div class="row">

                        <hr>



                        <?php if(Auth::user()->claseusr == 0): ?>
                            

                            <?php
                                header("Location: " . URL::to('/categoriasadmin'), true, 302);
                                exit();
                            ?>

                            
                        <?php else: ?>

                            
                            <?php if(Auth::user()->claseusr <> 4): ?>
                                <div class="col-md-4 text-center mt-2">
                            <?php else: ?>
                                <div class="col-md-6 text-center mt-2">
                            <?php endif; ?>                                
                                <form method="POST" action="<?php echo e(route('domicilio.update', '1')); ?>">
                                    <?php echo method_field('PUT'); ?>

                                    <?php echo csrf_field(); ?>

                                    <input type="hidden" name="empresa_id" value="<?php echo e($_COOKIE["idcompany"]); ?>">
                                
        
                                    <button class="btn nav-link btn-outline-primary btn-block  btn-lg" type="submit" >Domicilio</button>
                                    
                            
                                </form>
    
                            </div>
    
                            <?php if(Auth::user()->claseusr <> 4): ?>
                                <div class="col-md-4 text-center mt-2">
                            <?php else: ?>
                                <div class="col-md-6 text-center mt-2">
                            <?php endif; ?>
                                
                                <form method="POST" action="<?php echo e(route('enmesa.update', '1')); ?>">
                                    <?php echo method_field('PUT'); ?>

                                    <?php echo csrf_field(); ?>

                                    <input type="hidden" name="empresa_id" value="<?php echo e($_COOKIE["idcompany"]); ?>">
                                
        
                                    <button class="btn  btn-outline-secondary btn-block btn-lg" type="submit" >Mesa</button>
                                    
                            
                                </form>                            
                            </div>
                            <?php if(Auth::user()->claseusr <> 4): ?>
                                <div class="col-md-4 mt-2">
                                    
                                    <form method="POST" action="<?php echo e(route('reserva.update', '1')); ?>">
                                        <?php echo method_field('PUT'); ?>

                                        <?php echo csrf_field(); ?>

                                        <input type="hidden" name="empresa_id" value="<?php echo e($_COOKIE["idcompany"]); ?>">
                                    
            
                                        <button class="btn btn-outline-dark btn-block  btn-lg" type="submit" >Reserva</button>
                                        
                                
                                    </form>                              
                                </div>                        
                            <?php endif; ?>
                        <?php endif; ?>
                    



                    </div>
                    <?php endif; ?>

                    
                </div>
            </div>
        </div>
    </div>
</div>
<br>
<br>
<br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppServ\www\posshop\resources\views/home.blade.php ENDPATH**/ ?>