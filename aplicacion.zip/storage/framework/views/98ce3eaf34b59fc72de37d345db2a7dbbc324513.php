



<?php $__env->startSection('tittle', 'Productos'); ?>

<?php $__env->startSection('content'); ?>
<br>
<br>
<div class="container" >
    <div class="row justify-content-center">
        <div class="col-md-8">
            





            
            <div class=" "  style="background-color:<?php echo e($empresa->fodocolor); ?>;">
                <div class=" text-center">                    

                    <div class="row">
                        
                        <div class="column  p-1 img-centrada card-block">
                            

                                        

                            <img src="<?php echo e(URL::asset("/img/izq.png")); ?>" class="img-fluid" style="width:313px;">
                        </div>
                        <div class="column  p-2 img-centrada card-block ">
                            
                            <img src="<?php echo e(URL::asset("/img/der.png")); ?>" class="img-fluid" style="width:313px;">
                        </div>
                    </div>

                    <hr>
                </div>
                
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php else: ?>

                        <?php if(!Auth::check()): ?>
                            

                            <div class="text-center p-1">
                    
                                <?php if($empresa->estado == 1): ?>
                                
                                    <form method="POST" action="<?php echo e(route('login')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input name="email" type="hidden"  value="miguel_rueda@gmail.com" >
                                        <input name="password" type="hidden"  value="12345678" >
        
                                        <input type="submit" value="Ver la carta" class="btn btn-primary btn-block" >
                                    </form>
        
                                    
                                <?php else: ?>
                                    <h2>En el momento no estamos dando Servivio</h2>
                                <?php endif; ?>
            
        
                            </div>    

                        <?php else: ?>
                            <div class="row d-flex align-items-center justify-content-center">
                                <div class="col-sm-12 col-md-10  align-self-center text-center" >
                                    
                
                                    <a href="<?php echo e(url('/categorias')); ?>" class="btn-sm nav-link btn-block p-0 text-dark text-capitalize "  style="background-color: white;">
                                        
                                        <strong class="p-0">
                                            <h6 class ="p-3">Seguir Comprando</h6>
                                                
                                            
                                        </strong>
                                    </a>

                

                                </div>
                            </div>
                        <?php endif; ?>                

                    <?php endif; ?>

                    
                </div>
            </div>

        </div>
    </div>
</div>
<br>
<br>
<br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppServ\www\posshop\resources\views/main/home.blade.php ENDPATH**/ ?>