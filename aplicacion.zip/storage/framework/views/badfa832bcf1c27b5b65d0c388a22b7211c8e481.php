


<?php $__env->startSection('tittle', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

    
<br><br>
    <div class="container ">

        <div class="panel panel-default">

            <div class="panel-heading p-3">

                <h2>Reservas</h2>
                
                    
            </div>
            
            <div class="panel-body white p-2 ">
                <hr>
                
                <h3 class="ml-1">Estadísticas</h3>
                
                <div class="row top-space">
                    <div class="sale-data ml-n3">

                    </div>

                    <div class="col-xs-6 col-md-4 col-lg-3 sale-data">
                        
                        <span><?php echo e($reservasCount); ?></span>
                        Número de Reservas
                    </div>
                    
                </div>
                <br>
                <hr>

                <h3>Reservas</h3>
                 
                <table class="table table-bordered">

                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Cliente</th>
                            <th>Fecha</th>
                            <th>Hora</th>
                            <th>Personas</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $reservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                        <tr>
                            <td> <?php echo e($reserva->idreserva); ?> </td>
                            <td> <?php echo e($reserva->name); ?> </td>
                            <td> <?php echo e($reserva->fecha); ?> </td>
                            <td> <?php echo e(substr($reserva->hora,11)); ?> </td>

                            <td> <?php echo e($reserva->comensales); ?> </td>
                                
                        </tr>
                        <?php if($reserva->observacion): ?>
                            <tr>
                                <td colspan="1"></td>
                                <td colspan="4"> <?php echo e($reserva->observacion); ?> </td>                                
                            </tr
                        <?php endif; ?>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>

            </div>
    
        </div>
    <div>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppServ\www\posshop\resources\views/reservas/index.blade.php ENDPATH**/ ?>