
 

<?php $__env->startSection('content'); ?>
	

	<br>
	<br>

	



	<div class="container">

		<div class="row justify-content-center">
			<div class="col-md-12">
				
				<div class="card">
					<div class="card-header text-center"><h1>Listado de Categorias <a href="<?php echo e(route('categoriasadmin.create')); ?>">
						<button class="btn btn-xs btn-link"  data-toggle="tooltip"  title="Crear  Categoria">
							<i class="fas fa-plus-circle  fa-3x text-dark" aria-hidden="true"></i>
						</button></a></h1>
	
					   
					</div>
					<div class="card-body">

						<div class="table-responsive">
							<table class="table table-striped">
							
								<thead>
									
									<tr>
										<th>id</th>
										<th>Nombre</th>				
										<th>Visible</th>
									</tr>
										
								</thead>
					
					
								<tbody>
									
									<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td> <?php echo e($categoria->id); ?> </td>
					
											<td> <?php echo e($categoria->descripcion); ?> </td>
											

											<td>
												<a href="#" class="cat-habilitado" data-type="select" data-pk="<?php echo e($categoria->id); ?>" 
													data-url="<?php echo e(url("/categorias/$categoria->id")); ?>" 
													data-title="Visible"
													data-value="<?php echo e($categoria->visibleweb); ?>"
													data-name="visibleweb">
												</a>
											</td>											
											
							
											<td> 
												<div class="row">
												
												<a href="<?php echo e(route('categoriasadmin.edit', $categoria->id)); ?>" class="btn btn-link btn-xs" data-toggle="tooltip"  title="Editar Categoria">
													<i class="fas fa-edit  fa-1x" ></i>
												</a> 
					

					
												
												
					
												
												<a href="<?php echo e(route('prodcat.show', $categoria->id)); ?>" class="btn btn-link btn-xs"  data-toggle="tooltip" title="Crear Producto en esta Categoria" >
													
														<i class="fas fa-plus-circle  fa-1x" ></i>
													
												</a> 
												

 

												  <form class="no-padding" method="POST" action="<?php echo e(route('productos.show2')); ?>">
													<?php echo csrf_field(); ?>

													<input type="hidden" name="categoria" value="<?php echo e($categoria->id); ?>" >
													
													<button class="btn btn-link no-padding" type="submit" data-toggle="tooltip"  title="Ver Productos de la Categoria">
														<h5><i class='fas fa-cubes no-padding text-dark'  ></i></h5>
													</button>
												</form>	 
												</div>	    

											</td>
					
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
					
					
							</table>
						</div>	
					</div>
					<div class="card-footer  text-center" style="background-color: white;">

	
					</div>
	
				</div>
			</div>
		</div>
	</div>








<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


	<script type="text/javascript">
		$.fn.editable.defaults.mode = 'inline';
		$.fn.editable.defaults.ajaxOptions = {type: "PUT"};


		$.ajaxSetup({

			headers: {

				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

			}

		});
		$('.cat-habilitado').editable({
			source: [
				{value: 'T', text: 'Mostrar'}, 
				{value: 'F', text: 'Ocultar'}
			]
		});  



	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppServ\www\posshop\resources\views/categoriasadmin/index.blade.php ENDPATH**/ ?>