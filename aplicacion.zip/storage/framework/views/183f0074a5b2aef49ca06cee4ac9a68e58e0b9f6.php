<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="icon" href="<?php echo e(URL::asset("/img/iconop.png")); ?>">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" />

    <!-- Fonts -->
    


    <!-- Google Fonts -->

    

    <link href="https://fonts.googleapis.com/css2?family=Kodchasan:wght@200&display=swap" rel="stylesheet">





    <!-- X-editable -->
    <link href="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/jqueryui-editable/css/jqueryui-editable.css" rel="stylesheet"/>
    
    <!-- Datepicker Files -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
    
    <!-- Bootstrap Togle Files -->
    <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">

    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/css/mdb.min.css" rel="stylesheet">    

     <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">


  
    <?php echo $__env->yieldContent('estilo'); ?>
    


</head>
<body style="background-color:<?php echo e($empresa->fodocolor); ?>;">
    <div id="app" >
        <nav class="navbar navbar-expand-md navbar-light shadow-sm  sticky-top" style="background-color:<?php echo e($empresa->navvar); ?>;">
            <div class="container">
                <a class="navbar-brand nav-link text-white" href="<?php echo e(url('/')); ?>">


                    <img src="<?php echo e(URL::asset("/img/logo.png")); ?>" alt="..." class=" rounded-circle d-inline" style="width:40px;height:40px;">
                    <h3 class="d-inline  p-0 "><span style="color:<?php echo e($empresa->colletraenca); ?>; font-size:1rem;"><?php echo e($nombreEmpresa); ?></span></h3>
                    
                    
                </a>


                  <button class="navbar-toggler  d-md-none collapsed p-0" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                  </button>                  


                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <li class="<?php echo e(activeMenu('categorias*')); ?>" >
                            <?php if(auth()->check()): ?>
                                <?php if(Auth::user()->empresa_id > 0): ?>     
                                    
                                <?php endif; ?>
                            <?php endif; ?>
                        </li>

                        <?php if(auth()->check()): ?> 

                            <?php if(auth()->user()->claseusr == 0): ?> 
                                
                                 <?php if(Auth::user()->empresa_id > 0 and Auth::user()->empresa_id == 50000): ?>  
                                    <li class="<?php echo e(activeMenu('categorias*')); ?>" >
                                        
                                        <a href="<?php echo e(url('/categoriasadmin')); ?>" class="nav-link"  style="color:<?php echo e($empresa->colletramenu); ?>;">Categorias</a>

                                    </li>

                                    
                                    <li class="<?php echo e(activeMenu('productos*')); ?>" >
                                        
                                        <a href="<?php echo e(url('/productos')); ?>" class="nav-link " style="color:<?php echo e($empresa->colletramenu); ?>;">Productos</a>
                                    </li>
                                    <li class="<?php echo e(activeMenu('pedidos*')); ?>" >
                                        
                                        <a href="<?php echo e(url('/orders')); ?>" class="nav-link" style="color:<?php echo e($empresa->colletramenu); ?>;">Pedidos</a>
                                    </li>
                                    <li class="<?php echo e(activeMenu('reservas*')); ?>" >
                                        
                                        <a href="<?php echo e(url('/reservas')); ?>" class="nav-link" style="color:<?php echo e($empresa->colletramenu); ?>;">Reservas</a>
                                    </li>
                                <?php endif; ?>                                  
                                <?php if(Auth::user()->empresa_id > 0): ?>  

                                        <?php if( Auth::user()->empresa_id == 50000): ?> 
                                            <li class="<?php echo e(activeMenu('users*')); ?>" >
                                                
                                                <a href="<?php echo e(url('/empresas')); ?>" class="nav-link" style="color:<?php echo e($empresa->colletramenu); ?>;">Empresa</a>
                                            </li>
                                        <?php endif; ?>
                                        <li >
                                            
                                            <a href="#" class="estado-emp nav-link " data-type="select" data-pk="<?php echo e(Auth::user()->empresa_id); ?>" 
                                                data-url="<?php echo e(url("/empresasestado/".Auth::user()->empresa_id)); ?>" 
                                                data-title="estado"
                                                data-value="<?php echo e($estado); ?>"
                                                data-name="estado" style="color:<?php echo e($empresa->colletramenu); ?>;">
                                            </a>
                                            
                                        </li>
                                        <li class="<?php echo e(activeMenu('users*')); ?> inline" >

                                            <a href="<?php echo e(url('/notifications')); ?>" class="nav-link" style="color:<?php echo e($empresa->colletramenu); ?>;">Nuevo Pedido 

                                                 <span id="notif" class="no-padding">

                                                 </span>
    
                                            </a>
                                        </li>                                        
                                <?php endif; ?>                                  
                            <?php endif; ?>

                        <?php endif; ?> 

                        <?php if(auth()->guard()->guest()): ?>

                            
                        <?php else: ?>

                        <?php if(auth()->check()): ?> 

                            <?php if(auth()->user()->claseusr > 0): ?>       


                                <li class="nav-item dropdown collapsed" id="navbarDropdown">

                                    <?php if( $tipoCarrito <> 'Reserva'): ?>
                                    
                                        <?php if( $articulosCount>0): ?>
                                            
                                            <?php if( $estadoOrd <> "Aprobado"): ?>
                                                <h4>
                                                    <a href="<?php echo e(url('/carrito')); ?>" class="nav-link text-white" >
                                                        
                                                        <i class="fas fa-shopping-cart text-white"></i>
                                                        <span class="badge badge-secondary badge-pill bg-light text-dark">
                                                            <?php echo e($articulosCount); ?>

                                                        </span>
                                                    </a>
                                                </h4>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <h4>
                                                <i class="fas fa-shopping-cart text-white"></i>
                                                
                                                <span class="badge badge-secondary badge-pill bg-light text-dark">
                                                    <?php echo e($articulosCount); ?>

                                                </span>
                                            </h4>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                   
                                </li>  
                            <?php endif; ?>
                        <?php endif; ?>
                            <?php if( $estadoOrd <> "Aprobado"): ?>
                                <li class="nav-item ml-2 mt-1">
                                
                 
                                    <a class="pt-0" style="color:<?php echo e($empresa->colletramenu); ?>;" href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault();
                                                      document.getElementById('logout-form').submit();" style="color:<?php echo e($empresa->colletramenu); ?>;">
                                         Cancelar Pedido
                                     </a>
                                     <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main >
           

            
            <?php echo $__env->yieldContent('content'); ?>




            <header>

                <?php function activeMenu($url){
                        return request()->is($url) ? 'active' : '';
                        alert("hey");
                    }
                ?>

                <br>

            </header>
        </main>






        <footer class="page-footer  fixed-bottom ">

            <div style="background-color: <?php echo e($empresa->footercolor); ?>;">
              
                <div class="row justify-content-center align-items-center">
                    <div class="col-md text-center ">
                        <img src="<?php echo e(URL::asset("/img/letrero.jpg")); ?>"  >
                    </div>
        

                    <div class="col-md text-center">
                        Dirección: <?php echo e($empresa->direccion); ?>

                    </div>
                    <div class="col-md text-center">
                        Teléfono: <?php echo e($empresa->telefono); ?>

                    </div>
                </div>
            </div>

        </footer>
        <!-- Footer -->
        


    </div>

      <script type="text/javascript">
        
        var auto_refresh = setInterval(
            function(){
                $("#notif").load("<?php echo url('notificador'); ?>").fadeIn("slow"); 
                
            },1000);


    </script>  



    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

<!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js"></script>

<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/js/material.min.js"></script>

<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>



<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/js/ripples.min.js"></script>

<!-- Bootstrap Togle Files --> 
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>

<!-- Datepicker Files -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>

<!-- X-editable -->
<script src="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/jqueryui-editable/js/jqueryui-editable.min.js"></script>


<!-- Play Sound  <script type="text/javascript" src="http://mediaplayer.yahoo.com/js"></script>  -->






<?php echo $__env->yieldContent('scripts'); ?>



<script type="text/javascript">
    $.fn.editable.defaults.mode = 'inline';
    $.fn.editable.defaults.ajaxOptions = {type: "PUT"};


    $.ajaxSetup({

        headers: {

            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

        }

    });
    $('.estado-emp').editable({
        source: [
            {value: '1', text: 'Activo'}, 
            {value: '0', text: 'Inactivo'}
        ]
    });    
 



</script>


</body>
</html>
<?php /**PATH D:\AppServ\www\posshop\resources\views/layouts/app.blade.php ENDPATH**/ ?>