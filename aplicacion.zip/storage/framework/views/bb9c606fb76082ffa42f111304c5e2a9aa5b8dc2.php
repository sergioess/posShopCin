


<?php $__env->startSection('tittle', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

    
<br><br>
    <div class="container ">

        <div class="panel panel-default">

            <div class="panel-heading p-3">

                <h2>Pedidos</h2>
                
                    
            </div>
            
            <div class="panel-body white p-2">
                <hr>
                <h3 class="ml-1">Estadísticas</h3>

                <div class="row top-space">
                    

                    <div class="sale-data ml-n3">

                     </div>

                    <div class="col-xs-6 col-md-4 col-lg-3 sale-data">
                       <h5>COL</h5> 
                        <span><?php echo e(number_format($totalmes, 0)); ?></span>
                        Ingresos del Mes
                    </div>

                    <div class="col-xs-4 col-md-3 col-lg-3 sale-data">
                        <h5>No.</h5> 
                        <span><?php echo e($transacciones); ?></span>
                        Número de Ventas
                    </div>
                    
                </div>
                <br>
                <hr>

                <h3>Ventas</h3>
                
                <table class="table table-bordered">

                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Comprador</th>
                            <th>Dirección</th>
                            <th>Tipo</th>
                            <th  style="text-align:center">Status</th>
                            <th>Fecha</th>
                            <th>Total</th>
                            <th style="text-align:center">Domiciliario</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                        <tr>
                            <td> <?php echo e($order->id); ?> </td>
                            <td> <?php echo e($order->nombre_recibe); ?> </td>
                            <td> <?php echo e($order->direccion); ?> </td>
                            <td> <?php echo e($order->tipo); ?> </td>
                            <td  style="text-align:center"> 
 
                                <a href="#" class="select-status" data-type="select" data-pk="<?php echo e($order->id); ?>" 
                                    data-url="<?php echo e(url("/orders/$order->id")); ?>" 
                                    data-title="Status"
                                    data-value="<?php echo e($order->status); ?>"
                                    data-name="status">
                                </a>



                            </td>
                            <td> <?php echo e($order->created_at); ?> </td>
                            <td style="text-align:right"> <?php echo e(number_format($order->total, 0)); ?> </td>
                            <td  style="text-align:center"> 
 
                                <a href="#" class="numero_guia" id="<?php echo e($order->id); ?>" data-type="text" data-url="<?php echo e(url("/orders/$order->id")); ?>"  data-name="numero_guia" 
                                    data-pk="<?php echo e($order->id); ?>" class="editable editable-click" ><?php echo e($order->numero_guia); ?></a>


                                    

                                



                            </td>                            
                            <td> 

                                <a href="<?php echo e(route('notifications.show', $order->shopping_cart_id)); ?>"  target="_blank"  class="btn btn-link btn-xs" data-toggle="tooltip"  title="Imprimir">
                                    <i class="fas fa-print fa-2x" ></i>
                                </a> 


                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>

            </div>
    
        </div>
    <div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>


	<script type="text/javascript">
		$.fn.editable.defaults.mode = 'inline';
		$.fn.editable.defaults.ajaxOptions = {type: "PUT"};


		$.ajaxSetup({

			headers: {

				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

			}

		});
		$('.select-status').editable({
			source: [
				
				{value: 'recibido', text: 'Recibido'}, 
				{value: 'enviado', text: 'Enviado'} 
			]
		});

        $(function(){
            $('.numero_guia').editable({

            });
        });


	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppServ\www\posshop\resources\views/orders/index.blade.php ENDPATH**/ ?>