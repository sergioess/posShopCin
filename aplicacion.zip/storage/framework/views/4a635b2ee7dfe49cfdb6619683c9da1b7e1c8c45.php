<div class="container ">
                
    <?php if(isset($errors) && $errors->any()): ?>
        <br>
        <div class="alert alert-danger bg-white">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <?php echo e($error); ?>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if(session()->has('success')): ?>
        <br>
        <div class="alert alert-success bg-white">
            <ul>
                <?php $__currentLoopData = session()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <?php echo e($message); ?>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>                

    <?php if(session()->has('error')): ?>
        <br>
        <div class="alert alert-danger bg-white">
            <ul>
                
                    <li>
                        <?php echo e(session()->get('error')); ?>

                    </li>
                
            </ul>
        </div>
    <?php endif; ?>        

</div>
<?php /**PATH D:\AppServ\www\posshop\resources\views/components/mensajes.blade.php ENDPATH**/ ?>