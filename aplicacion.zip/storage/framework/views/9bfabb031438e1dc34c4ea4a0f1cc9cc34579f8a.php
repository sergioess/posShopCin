


<?php $__env->startSection('content'); ?>




<br>
<br>
		

<div class="container">

	<div class="row justify-content-center">
		<div class="col-md-12">

			<div class="card">
				<div class="card-header text-center">
					<h2>Productos</h2>
				</div>
				<div class="card-body">



					<form method="POST" action="<?php echo e(route('productos.update', $producto->id)); ?>"  enctype="multipart/form-data">
						

 

						<?php echo method_field('PUT'); ?>

					   <?php echo csrf_field(); ?> 
	   
						<p><label for="nombre">
						   Nombre
						   <input class="form-control"  type="text" name="nombre" size="50" value="<?php echo e($producto->descripcion); ?>">
						   <?php echo $errors->first('nombre','<span class=error>:message</span>'); ?>

					   </label></p>  
	   
						<p><label for="valor">
						   Valor
						   <input class="form-control"  type="text" name="valor" value="<?php echo e($producto->precio); ?>">
						   <?php echo $errors->first('valor','<span class=error>:message</span>'); ?>

					   
					   </label></p>
	   
					   


						<div class="form-group">
							<p>
								<label for="imagen">
									Imagen
									<?php echo Form::file('imagen', array('class' => 'form-control')); ?>


									<small class="text-danger"><?php echo e($errors->first('imagen')); ?></small>
								</label>
							</p>
						</div>


					   <p><label for="Link">
						   Link
						   <input class="form-control"  type="text" name="Link" value="<?php echo e($producto->habilitado); ?>">
						   <?php echo $errors->first('Link','<span class=error>:message</span>'); ?>

					   
					   </label></p>	 			
	   
	   
				   
	   
					   <p><input class="btn btn-primary"  type="submit" value= "Enviar" ></p>
				   </form>	 


				</div>
				<div class="card-footer  text-center" style="background-color: white;">


				</div>

			</div>
		</div>
	</div>
</div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppServ\www\posshop\resources\views/productos/edit.blade.php ENDPATH**/ ?>