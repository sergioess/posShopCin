


<?php $__env->startSection('content'); ?>
    <br>
    <br>
    <header class="big-padding text-center blue-grey white-text">
        <h1>Pedido Finalizado</h1>

    </header>

    <?php if($order->direccion != "0"): ?>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card large-padding">

                        <table class="table table-responsibe">
                            <tr class="text-center">
                                <td colspan="2">
                                    
                                    <h5><p>Verifica los datos de Tu entrega</p></h5>
                                    
                                </td>
                            </tr>

                            <tr>
                                <td>Nombre Recibe:</td>
                                <td><?php echo e($order->nombre_recibe); ?></td>
                            </tr>

                            <tr>
                                <td>Correo</td>
                                <td><?php echo e($order->email); ?></td>
                            </tr>



                            <tr>
                                <td>Dirección</td>
                                <td><?php echo e($order->direccion); ?></td>
                            </tr>
                            <tr>
                                <td>Barrio</td>
                                <td><?php echo e($order->barrio); ?></td>
                            </tr>

                        



                            <tr>
                                <td>Ciudad</td>
                                <td><?php echo e($order->ciudad); ?></td>
                            </tr>



                        </table>
                        <div class="text-center">
                            <a href="<?php echo e(url('/logout')); ?>" class="btn btn-primary nav-link">Volver a Comprar</a>

        

                        </div>
                    </div>
                </div>
            </div>

        </div>
    <?php else: ?>
    <div class="container">
        <div class="row  justify-content-center">
            <div class="text-center col-11 col-md-6">
                <a href="<?php echo e(url('/logout')); ?>" class="btn btn-primary nav-link">Volver a Comprar</a>
        
        
        
            </div>
        </div>

    </div>

    <?php endif; ?>
    <br>
    <br>
    <br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppServ\www\posshop\resources\views/shoppingcarts/complete.blade.php ENDPATH**/ ?>