

<?php $__env->startSection('content'); ?>
    <br>
    <br>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">

                <?php if(Auth::user()->empresa_id == 50000): ?>
                    <h1> <a href="<?php echo e(route('empresas.create')); ?>">
                    <button class="btn btn-xs btn-link"  data-toggle="tooltip"  title="Crear Empresa">
                        <i class="fa fa-plus-circle  fa-3x" aria-hidden="true"></i>
                    </button></a></h1>
                <?php endif; ?>

                <div class="panel p-3">
                    <div class="panel-heading">

                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="panel bg-secondary">
                                        <div class="panel-heading p-2 text-white">
                                            <h5><strong>Datos de la Empresa</strong></h5>
                                        </div>
                                        <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="panel-body">
                                                <table style="text-transform: none;" class="table table-condensed">
                                                    <tbody>
                                                        <tr>
                                                            <th><strong>Empresa:</strong></th>
                                                            <td><?php echo e($empresa->nombre); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th><strong>Nombre Fiscal:</strong></th>
                                                            <td><?php echo e($empresa->nombre_fiscal); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th><strong>NIT:</strong></th>
                                                            <td><?php echo e($empresa->nit); ?></td>
                                                        </tr>                                                    
                                                        <tr>
                                                            <th><strong>Email:</strong></th>
                                                            <td><?php echo e($empresa->email); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th><strong>Teléfono:</strong></th>
                                                            <td><?php echo e($empresa->telefono); ?></td>
                                                        </tr>
                                                        <!-- empresa -->
                                                        <tr>
                                                            <th><strong>Dirección:</strong></th>
                                                            <td><?php echo e($empresa->direccion.' - '.$empresa->barrio); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th><strong>Ciudad:</strong></th>
                                                            <td><?php echo e($empresa->ciudad.' - '.$empresa->departamento.' - '.$empresa->pais); ?></td>
                                                        </tr>


                                                    </tbody>
                                                </table>
                                            </div>
                                            <div id="toolbar-table">
                                                <div class="tab-pane active" >
                                                    
                                                    <a href="<?php echo e(route('empresas.edit', $empresa->id)); ?>" class="btn btn-info btn-embossed" title="Editar Datos Empresa">
                                                        <i class="fas fa-edit  fa-1x">&nbsp;</i>Editar
                                                    </a>

                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                
                            </div>
                
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppServ\www\posshop\resources\views/empresas/index.blade.php ENDPATH**/ ?>