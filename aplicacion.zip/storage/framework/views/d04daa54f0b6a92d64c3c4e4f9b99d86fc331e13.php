


<?php $__env->startSection('tittle', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>



    <?php if(Auth::user()->claseusr == 0): ?>


        <?php
            header("Location: " . URL::to('/categoriasadmin'), true, 302);
            exit();
        ?>


    <?php endif; ?>


    <div class="container ">
<br>

        <div class="article p-0 text-center">
            <a class="btn btn-primary  white-text capitalize"  class="tooltip-test" title="Nuevo Pedido" href="<?php echo e(route('home')); ?>">
                <h5><i class="fas fa-cart-plus"></i> Nuevo Pedido</h5>
            </a>
        </div>

        <br>
        <div class="panel panel-default p-1">

            <div class="panel-heading p-3 text-center">

                <h2>Últimos 10 Pedidos</h2>
                
                    
            </div>


                

                    
                    <table class="table table-bordered">

                        <thead>
                            <tr>
                                
                                <th>Fecha</th>
                                <th>Tipo</th>
                                
                                <th  style="text-align:center">Status</th>
                                
                                
                            </tr>
                        </thead>

                        <?php if(Auth::user()->claseusr == 1): ?>
                            <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                    <tr>
                                        
                                        <td> <?php echo e(date('d-m-Y', strtotime($order->fecha))); ?>  </td>
                                        <td> <?php echo e($order->tipo); ?> </td>
                                        
                                        
                                        <td> <?php echo e($order->status); ?> </td>
                                        
                                    
                                        

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>

                        <?php else: ?>
                            <tr>
                                <td colspan="3" class="text-center"> 
                                    <h4>Regístrate y podrás gestionar tus pedidos y recibir notificaciones por correo.
                                        <br>
                                        Sólo usuarios registrados pueden hacer recervas.
                                    </h4>
                                </td>
                            </tr>
                            
                        <?php endif; ?>
                    </table>

            </div>
    
        </div>
    <div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AppServ\www\posshop\resources\views/ordenclientes/index.blade.php ENDPATH**/ ?>