<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModinArticulo extends Model
{
    //
    protected $table = 'modin_articulos';


}
