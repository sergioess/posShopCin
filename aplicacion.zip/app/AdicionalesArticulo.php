<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdicionalesArticulo extends Model
{
    protected $table = 'adicionales_articulos';
}
