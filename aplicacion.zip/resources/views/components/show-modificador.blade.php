<div>
    {{-- @foreach ($modificadoresArticulos as $modificador) --}}
<tr>
    <td> -</td>
    {{-- <td> {{ $modificador->nommod }} </td> --}}
    
    <td>{{$articulo_id}}</td>
    <td> 0 </td>
</tr>
{{-- @endforeach  --}}
</div>