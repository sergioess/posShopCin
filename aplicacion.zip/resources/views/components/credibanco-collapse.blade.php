{{--  {!! Form::open(['method' => 'POST', 'route' => 'enviapedido.store', 'id'=>'paymentForm' ,'class' => 'form-horizontal', 'autocomplete' => 'off']) !!} 

<input name="amount" type="hidden"  value="{{ $total }}" >

<div class="text-center mt-3">
    <button type="submit" id="payButton" class="btn btn-primary btn-lg p-2">
        Pagar
    </button>
</div>

{!! Form::close() !!}   --}}


