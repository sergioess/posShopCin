
@if ($count )
    <span class='badge white'>
        <span class='text-dark '>{{ $count }}
        </span>
    </span>

    <audio autoplay src="song.mp3" >
        <p>If you are reading this, it is because your browser does not support the audio element.</p>
        </audio> 
        
@endif